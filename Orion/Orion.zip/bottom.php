<div id="bottom">
	<ul>
		<?php if ( !function_exists('dynamic_sidebar')
			|| !dynamic_sidebar("Footer") ) : ?>  
		<?php endif; ?>
	</ul>
	<div class="clear"> </div>
</div>
	
