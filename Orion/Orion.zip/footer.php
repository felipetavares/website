<div class="clear"></div>
</div>

<div class="footcover">
<div class="container">
<?php include (TEMPLATEPATH . '/bottom.php'); ?>
<div id="footer">

	<div class="fcred">
		Copyright &copy; <?php echo date('Y');?> <a href="<?php bloginfo('siteurl'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a> - <?php bloginfo('description'); ?>.<br />
<?php fflink(); ?> | <a href="http://topwpthemes.com/orion/" >Orion WP Theme</a> |
</div>	
	<div class='clear'></div>	
<?php wp_footer(); ?>

</div></div>


</div>
</body>
</html>      